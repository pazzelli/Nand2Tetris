Tic Tac Toe Game on the Hack Computer, released under the BSD 2-Clause License, also known as Simplified BSD or FreeBSD License
Copyright (c) 2013, John Pazzelli 
All rights reserved. 

This is an implementation of the classic Tic Tac Toe game on the Hack computer as part of the Nand2Tetris project.  The game features a 1 or 2-player mode with a computer-controlled player for single player games.  The computer AI uses a 'minimax' algorithm and has 3 levels of difficulty - the Impossible mode is unbeatable!


Instructions
--------------------------------------------
1. Open the Virtual Machine emulator supplied with the Nand2Tetris software files (run the /tools/VMEmulator.bat (Windows) or /tools/VMEmulator.sh (Unix/Linux) file)

2. Choose File --> Load Program and select the directory where the Tic Tac Toe game files are stored

3. Set the speed to Fast and the Animate dropdown to 'No Animation'

4. Select Run --> Run (or press F5) and enjoy!


License Information
--------------------------------------------
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met: 

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 


